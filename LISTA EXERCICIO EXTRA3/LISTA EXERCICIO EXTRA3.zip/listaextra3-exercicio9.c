#include <stdio.h>
#include <string.h>

int main() {
//declarando variaveis
    int aux=0,aux2=0;
    char palavra[51],letra1,letra2;
//rodando programa

    printf("Entre com a string:");
    gets(palavra);

    printf("informe o caractere a ser substituido:");
    scanf(" %c",&letra1);

    printf("informe o caractere substituto:");
    scanf(" %c",&letra2);

    aux=strlen(palavra);

    for (int y=0; y<=aux; y++){
        if (palavra[y]==letra1){
            palavra[y]=letra2;
        }
    }

    printf("A string com o caractere substituto fica: %s",palavra);


    return 0;
}
