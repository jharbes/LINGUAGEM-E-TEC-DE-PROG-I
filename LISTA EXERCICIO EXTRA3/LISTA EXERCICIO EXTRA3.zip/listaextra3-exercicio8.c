#include <stdio.h>
#include <string.h>

int main() {
//declarando variaveis
    int a[9],b[9],c[9];
//rodando programa

    printf("Entre com os valores dos arrays A e B, 10 numeros inteiros para cada.\n");

    for (int x=0;x<=9;x++){
        printf("A[%i]= ",x);
        scanf("%i",&a[x]);
        }
    printf("\n");

    for (int x=0;x<=9;x++){
        printf("B[%i]= ",x);
        scanf("%i",&b[x]);
        }
    printf("\n");

    for (int x=0;x<=9;x++){
        c[x]=a[x]-b[x];
        }

    for (int x=0;x<=9;x++){
        printf("C[%i]= %i\n",x,c[x]);
        }

    return 0;
}
