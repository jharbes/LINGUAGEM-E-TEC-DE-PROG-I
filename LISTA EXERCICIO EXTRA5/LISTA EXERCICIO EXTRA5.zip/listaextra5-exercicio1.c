#include <stdio.h>
#include <string.h>

int main() {
//declarando variaveis
    char n;
//rodando programa
    printf("TRANSFORMANDO MAIUSCULA EM MINUSCULA:\n");
    printf("\n");

    printf("Informe a letra maiuscula para converte-la em minusculo: ");
    scanf(" %c",&n);
    printf("\n");
    while (n<65 || n>90){
        printf("CARACTERE INFORMADO NAO EH LETRA MAISCULA! FAVOR REFAZER A OPERACAO.\n");
        printf("ENTRE COM UMA LETRA MAIUSCULA: ");
        scanf(" %c",&n);
    }

    n=n+32;

    printf("A respectiva letra minuscula eh %c.\n",n);
    printf("\n");

    return 0;
}
